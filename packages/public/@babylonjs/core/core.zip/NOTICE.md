Babylon.js
Copyright 2023 The Babylon.js team

The following components are included in this package:

Draco Compression [v1.5.6](https://github.com/google/draco/tree/1.5.6)
https://github.com/google/draco
Licensed under the Apache 2.0 License

Basis transcoder
Copyright 2024 The Khronos Group (https://www.khronos.org/),
Licensed under the Apache 2.0 license.

GLSLang [v11.8.0](https://github.com/KhronosGroup/glslang/releases/tag/11.8.0)
Copyright 2024 The Khronos Group (https://www.khronos.org/),
Licensed under the Apache 2.0 license.

TWGSL (https://github.com/BabylonJS/twgsl)
Copyright 20221-2024 The Babylon.js team
Licensed under the Apache 2.0 License
