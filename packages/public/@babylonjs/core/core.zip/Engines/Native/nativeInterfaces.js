export {};
//# sourceMappingURL=nativeInterfaces.js.map