/** @internal */
export interface IMaterialContext {
    uniqueId: number;
    reset(): void;
}
