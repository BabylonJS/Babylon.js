/** @internal */
export interface IComputeContext {
    clear(): void;
}
