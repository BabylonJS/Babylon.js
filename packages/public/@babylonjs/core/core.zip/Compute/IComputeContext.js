export {};
//# sourceMappingURL=IComputeContext.js.map