export {};
//# sourceMappingURL=inputInterfaces.js.map