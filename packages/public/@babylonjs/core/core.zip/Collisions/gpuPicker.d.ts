import type { AbstractMesh } from "../Meshes/abstractMesh.js";
import type { Nullable } from "../types.js";
import "../Shaders/picking.fragment";
import "../Shaders/picking.vertex";
/**
 * Class used to store the result of a GPU picking operation
 */
export interface IGPUPickingInfo {
    /**
     * Picked mesh
     */
    mesh: AbstractMesh;
}
/**
 * Class used to perform a picking operation using GPU
 * Please note that GPUPIcker cannot pick instances, only meshes
 */
export declare class GPUPicker {
    private _pickingTexure;
    private _idMap;
    private _idColors;
    private _cachedScene;
    private _renderMaterial;
    private _pickableMeshes;
    private _readbuffer;
    private _meshRenderingCount;
    private readonly _attributeName;
    private _createRenderTarget;
    private _createColorMaterial;
    /**
     * Set the list of meshes to pick from
     * Set that value to null to clear the list (and avoid leaks)
     * @param list defines the list of meshes to pick from
     */
    setPickingList(list: Nullable<Array<AbstractMesh>>): void;
    /**
     * Execute a picking operation
     * @param x defines the X coordinates where to run the pick
     * @param y defines the Y coordinates where to run the pick
     * @param disposeWhenDone defines a boolean indicating we do not want to keep resources alive (false by default)
     * @returns A promise with the picking results
     */
    pickAsync(x: number, y: number, disposeWhenDone?: boolean): Promise<Nullable<IGPUPickingInfo>>;
    private _readTexturePixelsAsync;
    /** Release the resources */
    dispose(): void;
}
