export {};
//# sourceMappingURL=animatable.interface.js.map