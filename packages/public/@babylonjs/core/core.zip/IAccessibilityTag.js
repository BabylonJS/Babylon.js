export {};
//# sourceMappingURL=IAccessibilityTag.js.map