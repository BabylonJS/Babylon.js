import { Camera } from "../camera";
/**
 * @internal
 */
export declare function setStereoscopicRigMode(camera: Camera): void;
