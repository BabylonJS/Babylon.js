import type { Camera } from "../camera";
/**
 * @internal
 */
export declare function setStereoscopicAnaglyphRigMode(camera: Camera): void;
