import type { Camera } from "../camera";
/**
 * @internal
 */
export declare function setVRRigMode(camera: Camera, rigParams: any): void;
