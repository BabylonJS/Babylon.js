var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var INSPECTOR;
(function (INSPECTOR) {
    /**
     * A search bar can be used to filter elements in the tree panel.
     * At each keypress on the input, the treepanel will be filtered.
     */
    var SearchBar = /** @class */ (function (_super) {
        __extends(SearchBar, _super);
        function SearchBar(tab) {
            var _this = _super.call(this) || this;
            _this._propTab = tab;
            _this._div.classList.add('searchbar');
            var filter = INSPECTOR.Inspector.DOCUMENT.createElement('i');
            filter.className = 'fa fa-search';
            _this._div.appendChild(filter);
            // Create input
            _this._inputElement = INSPECTOR.Inspector.DOCUMENT.createElement('input');
            _this._inputElement.placeholder = 'Filter by name...';
            _this._div.appendChild(_this._inputElement);
            _this._inputElement.addEventListener('keyup', function (evt) {
                var filter = _this._inputElement.value;
                _this._propTab.filter(filter);
            });
            return _this;
        }
        /** Delete all characters typped in the input element */
        SearchBar.prototype.reset = function () {
            this._inputElement.value = '';
        };
        SearchBar.prototype.update = function () {
            // Nothing to update
        };
        return SearchBar;
    }(INSPECTOR.BasicElement));
    INSPECTOR.SearchBar = SearchBar;
    var SearchBarDetails = /** @class */ (function (_super) {
        __extends(SearchBarDetails, _super);
        function SearchBarDetails(tab) {
            var _this = _super.call(this) || this;
            _this._detailTab = tab;
            _this._div.classList.add('searchbar');
            var filter = INSPECTOR.Inspector.DOCUMENT.createElement('i');
            filter.className = 'fa fa-search';
            _this._div.appendChild(filter);
            // Create input
            _this._inputElement = INSPECTOR.Inspector.DOCUMENT.createElement('input');
            _this._inputElement.placeholder = 'Filter by name...';
            _this._div.appendChild(_this._inputElement);
            _this._inputElement.addEventListener('keyup', function (evt) {
                var filter = _this._inputElement.value;
                _this._detailTab.searchByName(filter);
            });
            return _this;
        }
        /** Delete all characters typped in the input element */
        SearchBarDetails.prototype.reset = function () {
            this._inputElement.value = '';
        };
        SearchBarDetails.prototype.update = function () {
            // Nothing to update
        };
        return SearchBarDetails;
    }(INSPECTOR.BasicElement));
    INSPECTOR.SearchBarDetails = SearchBarDetails;
})(INSPECTOR || (INSPECTOR = {}));

//# sourceMappingURL=SearchBar.js.map
