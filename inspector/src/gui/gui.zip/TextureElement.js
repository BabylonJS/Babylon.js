var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var INSPECTOR;
(function (INSPECTOR) {
    /**
    * Display a very small div corresponding to the given texture. On mouse over, display the full image
    */
    var TextureElement = /** @class */ (function (_super) {
        __extends(TextureElement, _super);
        function TextureElement(tex) {
            var _this = _super.call(this) || this;
            _this._div.className = 'fa fa-search texture-element';
            // Create the texture viewer
            _this._textureDiv = INSPECTOR.Helpers.CreateDiv('texture-viewer', _this._div);
            // Img
            var imgDiv = INSPECTOR.Helpers.CreateDiv('texture-viewer-img', _this._textureDiv);
            // Texture size
            var sizeDiv = INSPECTOR.Helpers.CreateDiv(null, _this._textureDiv);
            if (tex) {
                sizeDiv.textContent = tex.getBaseSize().width + "px x " + tex.getBaseSize().height + "px";
                imgDiv.style.backgroundImage = "url('" + tex.url + "')";
                imgDiv.style.width = tex.getBaseSize().width + "px";
                imgDiv.style.height = tex.getBaseSize().height + "px";
            }
            _this._div.addEventListener('mouseover', _this._showViewer.bind(_this, 'flex'));
            _this._div.addEventListener('mouseout', _this._showViewer.bind(_this, 'none'));
            return _this;
        }
        TextureElement.prototype.update = function (tex) {
        };
        TextureElement.prototype._showViewer = function (mode) {
            this._textureDiv.style.display = mode;
        };
        return TextureElement;
    }(INSPECTOR.BasicElement));
    INSPECTOR.TextureElement = TextureElement;
})(INSPECTOR || (INSPECTOR = {}));

//# sourceMappingURL=TextureElement.js.map
