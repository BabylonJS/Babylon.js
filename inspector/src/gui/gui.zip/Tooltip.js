var INSPECTOR;
(function (INSPECTOR) {
    /**
     * Creates a tooltip for the parent of the given html element
     */
    var Tooltip = /** @class */ (function () {
        function Tooltip(elem, tip, attachTo) {
            if (attachTo === void 0) { attachTo = null; }
            var _this = this;
            this._elem = elem;
            if (!attachTo) {
                attachTo = this._elem.parentElement;
            }
            this._infoDiv = INSPECTOR.Helpers.CreateDiv('tooltip', attachTo);
            this._elem.addEventListener('mouseover', function () {
                _this._infoDiv.textContent = tip;
                _this._infoDiv.style.display = 'block';
            });
            this._elem.addEventListener('mouseout', function () { _this._infoDiv.style.display = 'none'; });
        }
        return Tooltip;
    }());
    INSPECTOR.Tooltip = Tooltip;
})(INSPECTOR || (INSPECTOR = {}));

//# sourceMappingURL=Tooltip.js.map
