var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var INSPECTOR;
(function (INSPECTOR) {
    /**
     * Represents a html div element.
     * The div is built when an instance of BasicElement is created.
     */
    var ColorPickerElement = /** @class */ (function (_super) {
        __extends(ColorPickerElement, _super);
        function ColorPickerElement(color, propertyLine) {
            var _this = _super.call(this) || this;
            var scheduler = INSPECTOR.Scheduler.getInstance();
            _this._div.className = 'color-element';
            _this._div.style.backgroundColor = _this._toRgba(color);
            _this.pline = propertyLine;
            _this._input = INSPECTOR.Helpers.CreateInput();
            _this._input.type = 'color';
            _this._input.style.opacity = "0";
            _this._input.style.width = '10px';
            _this._input.style.height = '15px';
            _this._input.value = color.toHexString();
            _this._input.addEventListener('input', function (e) {
                var color = BABYLON.Color3.FromHexString(_this._input.value);
                color.r = parseFloat(color.r.toPrecision(2));
                color.g = parseFloat(color.g.toPrecision(2));
                color.b = parseFloat(color.b.toPrecision(2));
                _this.pline.validateInput(color);
                scheduler.pause = false;
            });
            _this._div.appendChild(_this._input);
            _this._input.addEventListener('click', function (e) {
                scheduler.pause = true;
            });
            return _this;
        }
        ColorPickerElement.prototype.update = function (color) {
            if (color) {
                this._div.style.backgroundColor = this._toRgba(color);
                this._input.value = color.toHexString();
            }
        };
        ColorPickerElement.prototype._toRgba = function (color) {
            if (color) {
                var r = (color.r * 255) | 0;
                var g = (color.g * 255) | 0;
                var b = (color.b * 255) | 0;
                var a = 1;
                if (color instanceof BABYLON.Color4) {
                    a = color.a;
                }
                return "rgba(" + r + ", " + g + ", " + b + ", " + a + ")";
            }
            else {
                return '';
            }
        };
        return ColorPickerElement;
    }(INSPECTOR.BasicElement));
    INSPECTOR.ColorPickerElement = ColorPickerElement;
})(INSPECTOR || (INSPECTOR = {}));

//# sourceMappingURL=ColorPickerElement.js.map
