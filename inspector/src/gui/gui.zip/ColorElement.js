var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var INSPECTOR;
(function (INSPECTOR) {
    /**
    * Display a very small div corresponding to the given color
    */
    var ColorElement = /** @class */ (function (_super) {
        __extends(ColorElement, _super);
        // The color as hexadecimal string
        function ColorElement(color) {
            var _this = _super.call(this) || this;
            _this._div.className = 'color-element';
            _this._div.style.backgroundColor = _this._toRgba(color);
            return _this;
        }
        ColorElement.prototype.update = function (color) {
            if (color) {
                this._div.style.backgroundColor = this._toRgba(color);
            }
        };
        ColorElement.prototype._toRgba = function (color) {
            if (color) {
                var r = (color.r * 255) | 0;
                var g = (color.g * 255) | 0;
                var b = (color.b * 255) | 0;
                var a = 1;
                if (color instanceof BABYLON.Color4) {
                    a = color.a;
                }
                return "rgba(" + r + ", " + g + ", " + b + ", " + a + ")";
            }
            else {
                return '';
            }
        };
        return ColorElement;
    }(INSPECTOR.BasicElement));
    INSPECTOR.ColorElement = ColorElement;
})(INSPECTOR || (INSPECTOR = {}));

//# sourceMappingURL=ColorElement.js.map
